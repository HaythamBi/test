<?php
require APPPATH.'/libraries/REST_Controller.php';

class order_time_api extends REST_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('order_time_model');
	}

	function order_time_get() 
	{ 
		$data=$this->order_time_model->get();
		if($data!=null){
			$this->response($data); 
		}else{
			$this->response(array('empty'=>'empty_data'));
		}
	} 

	function order_time_post() 
	{ 
		$data = array('this not available');
		$this->response($data); 
	} 

	function order_time_put() 
	{ 
		$data = array('this not available'); 
		$this->response($data); 
	} 

	function order_time_delete() 
	{ 
		$data = array('this not available');
		$this->response($data); 
	}  
}
?>