<?php
  $config['verified_code_mail']='luann4099@gmail.com';
?>