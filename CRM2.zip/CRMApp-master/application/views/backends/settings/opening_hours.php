

<script type="text/javascript" src="<?php echo base_url()?>statics/tinymce/jquery.tinymce.js"></script>
<script type="text/javascript" src="<?php echo base_url()?>statics/switchery/switchery.min.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>statics/switchery/switchery.min.css"/>
<script type="text/javascript" src="<?php echo base_url() ?>statics/jquery-tokeninput/jquery.tokeninput.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>statics/jquery-tokeninput/token-input.css"/>
<section class="content-header">
	<h1>
		<?php echo lang('msg_settings'); ?>
		<small><?php echo lang(''); ?></small>
	</h1>
	<ol class="breadcrumb">
		<li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
		<li><a href="#"><?php echo lang('msg_dashboard'); ?></a></li>
		<li><a href="#"><?php echo lang('msg_settings'); ?></a></li>
		<li class="active"><?php echo lang('opening_hours'); ?></li>
	</ol>
</section>
<style>
	.days {
		color: #3c8dbc;
	}
</style>

<section class="content">
	<!--show alert messager-->
	<div class="box box-primary">
		<div class="box-header with-border">

			<h3 class="box-title"><?php echo lang('opening_hours'); ?></h3>
		</div><br>


		<form class="form-horizontal" id="form" method="post" action="<?= base_url().'admin/settings/add'?>" enctype="multipart/form-data">
			<!-- <audio id="myAudio">
				<source src="http://customer1.eastus.cloudapp.azure.com/cms/alarm.mp3" type="audio/mpeg">
				</audio> -->
				<div style="text-align: right; margin-right: 30px;">
					<label class="control-label " for="txtName" style="color: red;"><?php echo lang('emergency_closed');?></label>&nbsp;
					<input type="checkbox" name="emergency_closed" id="closed" value="<?= (!empty($record))?$record['emergency_closed']:'' ?>" class="js-switch" <?= (!empty($record) && $record['emergency_closed'] == 'yes')?'checked':'' ?>>
				</div><br>
				<div style="text-align: right; margin-right: 30px;">
					<label class="control-label days" for="txtName" ><?php echo lang('ring');?></label>&nbsp;
					<input type="checkbox" name="ring_status" id="closed" value="<?= (!empty($record))?$record['ring_status']:'' ?>" class="js-switch" <?= (!empty($record) && $record['ring_status'] == 'yes')?'checked':'' ?>>
				</div>

				<div class="form-group">
					<label class="control-label days" for="txtName"><?php echo lang('monday');?></label><br><br>
					<div class="col-md-4">
						<label class="col-md-4" for="txtName" style="font-size: 12px !important;"><?php echo lang('start_time');?></label>
						<div class="controls col-md-8">
							<input type="time" id="m_start_time" class="form-control" name="m_start_time" value="<?= (!empty($record) && $record['m_start_time'] != '')?date('H:i' , strtotime($record['m_start_time'])):'' ?>" <?= (!empty($record) && $record['m_closed'] == 'yes')?'disabled':'' ?>>
						</div>
					</div>
					<div class="col-md-4">
						<label class="control-label col-md-4" for="txtName" style="font-size: 12px !important;"><?php echo lang('end_time');?></label>
						<div class="controls col-md-8">
							<input type="time" id="m_end_time" class="form-control" name="m_end_time" value="<?= (!empty($record) && $record['m_end_time'] != '')?date('H:i' , strtotime($record['m_end_time'])):'' ?>" <?= (!empty($record) && $record['m_closed'] == 'yes')?'disabled':'' ?>>
						</div>
					</div>
					<div class="col-md-4">
						<label class="control-label col-sm-2" for="txtName" style="font-size: 12px !important;"><?php echo lang('closed')?></label>
						<div class="col-sm-10">
							<input type="checkbox" name="m_closed" id="closed" value="<?= (!empty($record))?$record['m_closed']:'' ?>" class="js-switch" <?= (!empty($record) && $record['m_closed'] == 'yes')?'checked':'' ?>>
						</div>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label days" for="txtName"><?php echo lang('tuesday');?></label><br><br>
					<div class="col-md-4">
						<label class="col-md-4" for="txtName" style="font-size: 12px !important;"><?php echo lang('start_time');?></label>
						<div class="controls col-md-8">
							<input type="time" id="tu_start_time" class="form-control" name="tu_start_time" value="<?= (!empty($record) && $record['tu_start_time'] != '')?date('H:i', strtotime($record['tu_start_time'])):'' ?>" <?= (!empty($record) && $record['tu_closed'] == 'yes')?'disabled':'' ?>>
						</div>
					</div>
					<div class="col-md-4">
						<label class="control-label col-md-4" for="txtName" style="font-size: 12px !important;"><?php echo lang('end_time');?></label>
						<div class="controls col-md-8">
							<input type="time" id="tu_end_time" class="form-control" name="tu_end_time" value="<?= (!empty($record) && $record['tu_end_time'] != '')?date('H:i', strtotime($record['tu_end_time'])):'' ?>" <?= (!empty($record) && $record['tu_closed'] == 'yes')?'disabled':'' ?>>
						</div>
					</div>
					<div class="col-md-4">
						<label class="control-label col-sm-2" for="txtName" style="font-size: 12px !important;"><?php echo lang('closed')?></label>
						<div class="col-sm-10">
							<input type="checkbox" name="tu_closed" id="closed" value="<?= (!empty($record))?$record['tu_closed']:'' ?>" class="js-switch" <?= (!empty($record) && $record['tu_closed'] == 'yes')?'checked':'' ?>>
						</div>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label days" for="txtName"><?php echo lang('wednesday');?></label><br><br>
					<div class="col-md-4">
						<label class="col-md-4" for="txtName" style="font-size: 12px !important;"><?php echo lang('start_time');?></label>
						<div class="controls col-md-8">
							<input type="time" id="w_start_time" class="form-control" name="w_start_time" value="<?= (!empty($record) && $record['w_start_time'] != '')?date('H:i', strtotime($record['w_start_time'])):'' ?>" <?= (!empty($record) && $record['w_closed'] == 'yes')?'disabled':'' ?>>
						</div>
					</div>
					<div class="col-md-4">
						<label class="control-label col-md-4" for="txtName" style="font-size: 12px !important;"><?php echo lang('end_time');?></label>
						<div class="controls col-md-8">
							<input type="time" id="w_end_time" class="form-control" name="w_end_time" value="<?= (!empty($record) && $record['w_end_time'] != '')?date('H:i' , strtotime($record['w_end_time'])):'' ?>" <?= (!empty($record) && $record['w_closed'] == 'yes')?'disabled':'' ?>>
						</div>
					</div>
					<div class="col-md-4">
						<label class="control-label col-sm-2" for="txtName" style="font-size: 12px !important;"><?php echo lang('closed')?></label>
						<div class="col-sm-10">
							<input type="checkbox" name="w_closed" id="closed" value="<?= (!empty($record))?$record['w_closed']:'' ?>" class="js-switch" <?= (!empty($record) && $record['w_closed'] == 'yes')?'checked':'' ?>>
						</div>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label days" for="txtName"><?php echo lang('thursday');?></label><br><br>
					<div class="col-md-4">
						<label class="col-md-4" for="txtName" style="font-size: 12px !important;"><?php echo lang('start_time');?></label>
						<div class="controls col-md-8">
							<input type="time" id="th_start_time" class="form-control" name="th_start_time" value="<?= (!empty($record) && $record['th_start_time'] != '')?date('H:i', strtotime($record['th_start_time'])):'' ?>" <?= (!empty($record) && $record['th_closed'] == 'yes')?'disabled':'' ?>>
						</div>
					</div>
					<div class="col-md-4">
						<label class="control-label col-md-4" for="txtName" style="font-size: 12px !important;"><?php echo lang('end_time');?></label>
						<div class="controls col-md-8">
							<input type="time" id="th_end_time" class="form-control" name="th_end_time" value="<?= (!empty($record) && $record['th_end_time'] != '')?date('H:i' , strtotime($record['th_end_time'])):'' ?>" <?= (!empty($record) && $record['th_closed'] == 'yes')?'disabled':'' ?>>
						</div>
					</div>
					<div class="col-md-4">
						<label class="control-label col-sm-2" for="txtName" style="font-size: 12px !important;"><?php echo lang('closed')?></label>
						<div class="col-sm-10">
							<input type="checkbox" name="th_closed" id="closed" value="<?= (!empty($record))?$record['th_closed']:'' ?>" class="js-switch" <?= (!empty($record) && $record['th_closed'] == 'yes')?'checked':'' ?>>
						</div>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label days" for="txtName"><?php echo lang('friday');?></label><br><br>
					<div class="col-md-4">
						<label class="col-md-4" for="txtName" style="font-size: 12px !important;"><?php echo lang('start_time');?></label>
						<div class="controls col-md-8">
							<input type="time" id="f_start_time" class="form-control" name="f_start_time" value="<?= (!empty($record) && $record['f_start_time'] != '')?date('H:i', strtotime($record['f_start_time'])):'' ?>" <?= (!empty($record) && $record['f_closed'] == 'yes')?'disabled':'' ?>>
						</div>
					</div>
					<div class="col-md-4">
						<label class="control-label col-md-4" for="txtName" style="font-size: 12px !important;"><?php echo lang('end_time');?></label>
						<div class="controls col-md-8">
							<input type="time" id="f_end_time" class="form-control" name="f_end_time" value="<?= (!empty($record) && $record['f_end_time'] != '')?date('H:i' , strtotime($record['f_end_time'])):'' ?>" <?= (!empty($record) && $record['f_closed'] == 'yes')?'disabled':'' ?>>
						</div>
					</div>
					<div class="col-md-4">
						<label class="control-label col-sm-2" for="txtName" style="font-size: 12px !important;"><?php echo lang('closed')?></label>
						<div class="col-sm-10">
							<input type="checkbox" name="f_closed" id="closed" value="<?= (!empty($record))?$record['f_closed']:'' ?>" class="js-switch" <?= (!empty($record) && $record['f_closed'] == 'yes')?'checked':'' ?>>
						</div>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label days" for="txtName"><?php echo lang('saturday');?></label><br><br>
					<div class="col-md-4">
						<label class="col-md-4" for="txtName" style="font-size: 12px !important;"><?php echo lang('start_time');?></label>
						<div class="controls col-md-8">
							<input type="time" id="sa_start_time" class="form-control" name="sa_start_time" value="<?= (!empty($record) && $record['sa_start_time'] != '')?date('H:i' ,strtotime($record['sa_start_time'])):'' ?>" <?= (!empty($record) && $record['sa_closed'] == 'yes')?'disabled':'' ?>>
						</div>
					</div>
					<div class="col-md-4">
						<label class="control-label col-md-4" for="txtName" style="font-size: 12px !important;"><?php echo lang('end_time');?></label>
						<div class="controls col-md-8">
							<input type="time" id="sa_end_time" class="form-control" name="sa_end_time" value="<?= (!empty($record) && $record['sa_end_time'] != '')?date('H:i' , strtotime($record['sa_end_time'])):'' ?>" <?= (!empty($record) && $record['sa_closed'] == 'yes')?'disabled':'' ?>>
						</div>
					</div>
					<div class="col-md-4">
						<label class="control-label col-sm-2" for="txtName" style="font-size: 12px !important;"><?php echo lang('closed')?></label>
						<div class="col-sm-10">
							<input type="checkbox" name="sa_closed" id="closed" value="<?= (!empty($record))?$record['sa_closed']:'' ?>" class="js-switch" <?= (!empty($record) && $record['sa_closed'] == 'yes')?'checked':'' ?>>
						</div>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label days" for="txtName"><?php echo lang('sunday');?></label><br><br>
					<div class="col-md-4">
						<label class="col-md-4" for="txtName" style="font-size: 12px !important;"><?php echo lang('start_time');?></label>
						<div class="controls col-md-8">
							<input type="time" id="su_start_time" class="form-control" name="su_start_time" value="<?= (!empty($record) && $record['su_start_time'] != '')?date('H:i', strtotime($record['su_start_time'])):'' ?>" <?= (!empty($record) && $record['su_closed'] == 'yes')?'disabled':'' ?>>
						</div>
					</div>
					<div class="col-md-4">
						<label class="control-label col-md-4" for="txtName" style="font-size: 12px !important;"><?php echo lang('end_time');?></label>
						<div class="controls col-md-8">
							<input type="time" id="su_end_time" class="form-control" name="su_end_time" value="<?= (!empty($record) && $record['su_end_time'] != '')?date('H:i', strtotime($record['su_end_time'])):'' ?>" <?= (!empty($record) && $record['su_closed'] == 'yes')?'disabled':'' ?>>
						</div>
					</div>
					<div class="col-md-4">
						<label class="control-label col-sm-2" for="txtName" style="font-size: 12px !important;"><?php echo lang('closed')?></label>
						<div class="col-sm-10">
							<input type="checkbox" name="su_closed" id="closed" value="<?= (!empty($record))?$record['su_closed']:'' ?>" class="js-switch" <?= (!empty($record) && $record['su_closed'] == 'yes')?'checked':'' ?>>
						</div>
					</div>
				</div>

				<div class="form-group" style="padding: 20px;">
					<?php if(empty($record)){ ?>
						<button type="submit"  class="btn btn-primary" >
							<?php echo lang('msg_save')?>
						</button>
					<?php } else{ ?>
						<button type="submit" class="btn btn-primary" >
							<?php echo lang('update')?>
						</button>
					<?php } ?>
				</div>

			<!-- 
			<div class="form-group">
				<div class="col-md-10 col-md-offset-2">
					<button type="submit" class="btn btn-primary" >
						<?php echo lang('msg_save');?>
					</button>
					<a href="<?php echo base_url();?>admin/settings/reset_mail_settings" class="btn btn-default">
						<?php echo lang('reset_default');?>
					</a>
				</div>
			</div> -->

		</form>
	</div>

</div>
</section>

<!-- <div id="alarm_modal" class="modal" tabindex="-1" role="dialog">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-body">
				<p>Someone placed an order.</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-primary" id="ok_order">Ok</button>
			</div>
		</div>
	</div>
</div>
 -->
<!-------------------------------------------------alarm modal ------------------------------------------------------>

<!-- <div class="modal fade" id="alarm_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-body">
				<div class="row">
					<div class="col-sm-12 text-center">
						<span style="font-size: 18px;">Someone placed an order.</span>
						<button type="hidden" class="close" data-dismiss="modal" aria-label="Close">
						</button>
					</div><br>
				</div>
				<div class="row">
					<div id="change_driver_error"></div>
				</div>
				<form id="driver_form">
					<div class="form-group item" style="visibility: hidden;">
						<label for="recipient-name" class="col-form-label">Load ID</label>
						<input type="text" readonly class="form-control" id="load_id">
					</div>
					<div class="form-group">
						<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-5">
							<button type="button" class="btn btn-info" id="ok_order">Ok</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div> -->

<!------------------------------------------close-------alarm modal ------------------------------------------------------>
<!-- <script src="https://www.gstatic.com/firebasejs/8.8.0/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.8.0/firebase-database.js"></script> -->
<script type="text/javascript">
	var elem = $('.js-switch');
	var init;
	elem.each(function(index){
		init = new Switchery($(this)[0]);
		($(this)[0]).onchange = function() {
			if(($(this)[0]).checked){
			// var val = elem.closest('#closed').attr('id');
			var attrName = $(this).attr("name");

			if(attrName == 'm_closed'){
				$('#m_start_time').attr('disabled',true);
				$('#m_end_time').attr('disabled',true);
			}
			else if(attrName == 'tu_closed'){
				$('#tu_start_time').attr('disabled',true);
				$('#tu_end_time').attr('disabled',true);
			}
			else if(attrName == 'w_closed'){
				$('#w_start_time').attr('disabled',true);
				$('#w_end_time').attr('disabled',true);
			}
			else if(attrName == 'th_closed'){
				$('#th_start_time').attr('disabled',true);
				$('#th_end_time').attr('disabled',true);
			}
			else if(attrName == 'f_closed'){
				$('#f_start_time').attr('disabled',true);
				$('#f_end_time').attr('disabled',true);
			}
			else if(attrName == 'sa_closed'){
				$('#sa_start_time').attr('disabled',true);
				$('#sa_end_time').attr('disabled',true);
			}else{
				if(attrName == 'su_closed'){
					$('#su_start_time').attr('disabled',true);
					$('#su_end_time').attr('disabled',true);
				}
			}
		}else{
			var Name = $(this).attr("name");
			if(Name == 'm_closed'){
				$('#m_start_time').attr('disabled',false);
				$('#m_end_time').attr('disabled',false);
			}
			else if(Name == 'tu_closed'){
				$('#tu_start_time').attr('disabled',false);
				$('#tu_end_time').attr('disabled',false);
			}
			else if(Name == 'w_closed'){
				$('#w_start_time').attr('disabled',false);
				$('#w_end_time').attr('disabled',false);
			}
			else if(Name == 'th_closed'){
				$('#th_start_time').attr('disabled',false);
				$('#th_end_time').attr('disabled',false);
			}
			else if(Name == 'f_closed'){
				$('#f_start_time').attr('disabled',false);
				$('#f_end_time').attr('disabled',false);
			}
			else if(Name == 'sa_closed'){
				$('#sa_start_time').attr('disabled',false);
				$('#sa_end_time').attr('disabled',false);
			}else{
				if(Name == 'su_closed'){
					$('#su_start_time').attr('disabled',false);
					$('#su_end_time').attr('disabled',false);
				}
			}
		}
	};
})

	/*<?php
	$settings= getSettings(GENERAL_SETTING_FILE);
	$currency = $settings['currency_symbol'];
	?>*/

</script>
<!-- <script type="text/javascript">
	const firebaseConfig = {
		apiKey: "AIzaSyB5dY7HqMHqWWOddbrSemiNcmE7ybrrFOI",
		authDomain: "tortia-37136.firebaseapp.com",
		databaseURL: "https://tortia-37136.firebaseio.com",
		projectId: "tortia-37136",
		storageBucket: "tortia-37136.appspot.com",
		messagingSenderId: "613153207826",
		appId: "1:613153207826:web:9c1dd0294418a478aa8acb",
		measurementId: "G-W1LZZM91E2"
	};

	// Initialize Firebase
	const app = firebase.initializeApp(firebaseConfig);

	var i = 0;
	var starCountRef = firebase.database().ref('order_received');
	starCountRef.on('value', (snapshot) => {
		const data = snapshot.val();
		console.log(data);
		if(i == 1){
			$('#myAudio')[0].play();
			$('#myAudio').attr('loop' , '');
			$('#alarm_modal').modal('show');
		}
		i = 1;
	});
</script>
<script type="text/javascript">
	$(document).on('click' , '#ok_order' , function(event) {
		$('#ok_order').attr("disabled", "disabled");
		$('#myAudio').removeAttr('loop');
		$('alarm_modal').modal('hide');
		location.reload();
		// var formData = new FormData($('#driver_form')[0]);

	});
</script> -->
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> -->
