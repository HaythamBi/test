<!doctype html>
<html>
<head>
	<?php 
	$CI =& get_instance();
	$CI->load->view('backends/commons/header');
	?>
</head>
<body class="hold-transition skin-blue sidebar-mini">
	<div class="wrapper">
		<?php
		$CI->load->view('backends/commons/topmenu');
		?>
		
		<div class="content-wrapper">
			<?php echo $content; ?>
		</div>
		<?php
		$CI->load->view('backends/commons/footer');
		$CI->load->view('backends/commons/sidebar-2');
		?>
	</div>
</body>
</html>