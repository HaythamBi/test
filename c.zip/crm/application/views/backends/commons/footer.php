<footer class="main-footer">
  <div class="pull-right hidden-xs">
      <?php
      echo lang('msg_version');
      ?>
  </div>
  <?php
  echo lang('copyright');
  ?>
</footer>
