<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<title>Restaurant CMS</title>
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url().'statics/bootstrap/css/bootstrap.min.css'?>" />
<!-- <link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url().'statics/bootstrap/css/bootstrap-responsive.min.css'?>"/> -->

<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url().'statics/admin-lte/css/AdminLTE.min.css'?>"/>
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url().'statics/admin-lte/css/skins/_all-skins.css'?>"/>

<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url().'statics/font-awesome/css/font-awesome.min.css'?>"/>

<script type="text/javascript" src="<?php echo base_url().'statics/js/jquery.min.js'?>"></script>
<script type="text/javascript" src="<?php echo base_url().'statics/bootstrap/js/bootstrap.min.js'?>"></script>

<script type="text/javascript" src="<?php echo base_url().'statics/admin-lte/js/adminlte.min.js'?>"></script>
<script type="text/javascript" src="<?php echo base_url().'statics/admin-lte/js/demo.js'?>"></script>

<script type="text/javascript" src="<?php echo base_url().'statics/js/jquery_validation/jquery.validate.min.js'?>"></script>
<script type="text/javascript" src="<?php echo base_url().'statics/js/jquery_validation/additional-methods.min.js'?>"></script>

<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url().'statics/css/index.css'?>"/>
<?php
$query = $this->db->get('opening_hours');
$data = $query->row_array();
?>
<div>
    <input type="hidden" name="ring_status" id="ring_status" value="<?= !empty($data)?$data['ring_status']:'' ?>">
	<input type="hidden" name="firebase_key" id="firebase_key" value="23111101">
	<input type="hidden" name="session_val" id="session_val" value="<?= isset($_SESSION['user'])?'yes':'no' ?>">

    <audio id="myAudio">
        <source src="http://172.173.195.97/crm/alarm.mp3" type="audio/mpeg">
        </audio>
    </div>

    <div id="alarm_modal" class="modal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header bg-primary">
                    <h3 class="modal-title">New Order</h3>
                </div>
                <div class="modal-body">
                    <p class="text-primary text-center">Someone placed an order.</p>
                </div>
                <div class="modal-footer" style="text-align: center;">
                    <button type="button" class="btn btn-primary" style="padding-left: 50px; padding-right: 50px;" id="ok_order">Ok</button>
                </div>
            </div>
        </div>
    </div>

<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<script src="https://www.gstatic.com/firebasejs/7.20.0/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.20.0/firebase-storage.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.20.0/firebase-database.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.20.0/firebase-functions.js"></script>
    <script type="text/javascript">
/*	var fir_val = 0;
	var i = 0;
        const firebaseConfig = {
            apiKey: "AIzaSyB5dY7HqMHqWWOddbrSemiNcmE7ybrrFOI",
            authDomain: "tortia-37136.firebaseapp.com",
            databaseURL: "https://tortia-37136.firebaseio.com",
            projectId: "tortia-37136",
            storageBucket: "tortia-37136.appspot.com",
            messagingSenderId: "613153207826",
            appId: "1:613153207826:web:9c1dd0294418a478aa8acb",
            measurementId: "G-W1LZZM91E2"
        };

    // Initialize Firebase
    firebase.initializeApp(firebaseConfig);
    
    firebase.database().ref('order_received').on('value', (snapshot) => {
	
        const data = snapshot.val();
	fir_val = data;
        var ring_status = document.getElementById("ring_status").value;
	//var fire_key= $('#firebase_key').val();
	var x = document.getElementById("myAudio");
	var str = window.location.href;
	var arr=str.split('/');
	var session = $('#session_val').val();
	console.log(session);
	console.log(data );
	console.log(arr[6]);
        if(arr[6] && arr[6] != data && ring_status == 'yes' && session == "yes"){
            //x.play();
		console.log('dsdsds');
		i = data;
		$('#firebase_key').val(data);
		console.log(data);
		
            //$('#myAudio').attr('loop' , '');
	    $('#myAudio')[0].play();
            $('#myAudio').attr('loop' , '');
	$('#alarm_modal').modal('show');
        }
	else if(typeof arr[6] === 'undefined' && ring_status == 'yes' && session == "yes"){
            //x.play();
		console.log('dsds');
		i = data;
		$('#firebase_key').val(data);
		console.log(data);
		
            //$('#myAudio').attr('loop' , '');
	    $('#myAudio')[0].play();
            $('#myAudio').attr('loop' , '');
	$('#alarm_modal').modal('show');
        }

        
    });

$(document).on('click' , '#ok_order' , function(event) {
        $('#ok_order').attr("disabled", "disabled");
	//var x = document.getElementById("myAudio");
        //x.pause();
        //$('#alarm_modal').modal('hide');
	$('#myAudio').removeAttr('loop');
        $('#alarm_modal').modal('hide');
	$('#firebase_key').val(fir_val);
	i = 1;
	console.log($('#firebase_key').val());

        window.location = '<?= base_url() ?>' + 'admin/orders/'+fir_val;       
    });
*/
</script>
<script type="text/javascript">
    
</script>