<?php
class Settings extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if (!isset($_SESSION['user'])) {
            redirect('admin/dashboard');
        } else {
            $user=$_SESSION['user'][0];
            if ($user->perm==USER) {
                redirect('admin/denied');
            }
        }
        $this->load->helper('settings');
        $this->form_validation->set_error_delimiters('<div class="error-line">', '</div>');
        $check = TRUE;
    }

    public function general()
    {
        $this->load->model('countries_model');
        if (isset($_POST['currency'])) {
            $id=$this->input->post('currency');
            $settings['currency_id']=$id;
            $currency_symbol=$this->countries_model->get_by_id($id);
            $settings['currency_symbol']=$currency_symbol[0]->currency_symbol;
            $settings['country_code']=$currency_symbol[0]->iso_alpha2;
            $settings['language_code']=$currency_symbol[0]->language_code;
            $settings['currency_code']=$currency_symbol[0]->currency_code;
            $settings['tax']=$this->input->post('tax');
            $settings['ship_fee']=$this->input->post('ship_fee');
            $settings['terms_and_conditions']=$this->input->post('terms_and_conditions');

            $settings['address']=$this->input->post('address');
            $settings['sub_address']=$this->input->post('sub_address');

            $settings['website']=$this->input->post('website');
            $settings['twitter']=$this->input->post('twitter');
            $settings['facebook']=$this->input->post('facebook');
            $settings['instagram']=$this->input->post('instagram');
            $settings['pinterest']=$this->input->post('pinterest');
            $settings['google_plus']=$this->input->post('google_plus');
            $settings['youtube']=$this->input->post('youtube');
            $settings['mail']=$this->input->post('mail');
            $settings['sub_mail']=$this->input->post('sub_mail');
            $settings['phone']=$this->input->post('phone');
            $settings['sub_phone']=$this->input->post('sub_phone');
            $settings['ship_fee']=$this->input->post('ship_fee');

            $settings['distance']=$this->input->post('distance');
            $settings['lat']=$this->input->post('lat');
            $settings['lng']=$this->input->post('lng');

            setSettings($settings, GENERAL_SETTING_FILE);
        }
        $data['obj']=getSettings(GENERAL_SETTING_FILE);
        $data['list']=$this->countries_model->get_currency();
        $data['heading']=$this->lang->line('msg_settings').'-'.$this->lang->line('msg_general');
        $this->template->write_view('content', 'backends/settings/general', $data);
        $this->template->render();
    }

    public function reset_general_settings()
    {
        resetGeneral();
        redirect('admin/settings/general');
    }

    public function payments()
    {
        if (isset($_POST['public_key'])) {
            $public_key=$this->input->post('public_key');
            $secret_key=$this->input->post('secret_key');
            $settings=array();
            $settings['public_key']=$public_key;
            $settings['secret_key']=$secret_key;
            setSettings($settings, PAYMENT_SETTING_FILE);
        }

        $data['obj']=getSettings(PAYMENT_SETTING_FILE);
        $this->template->write_view('content', 'backends/settings/payment', $data);
        $this->template->render();
    }

    public function reset_payments_settings()
    {
        resetPayments();
        redirect('admin/settings/payments');
    }

    public function mail()
    {
        if (isset($_POST['host'])) {
            $host=$this->input->post('host');
            $user=$this->input->post('user');
            $pwd=$this->input->post('pwd');
            $port=$this->input->post('port');
            $mailpath=$this->input->post('mail_path');
            $from_user=$this->input->post('from_user');
            $from_email=$this->input->post('from_email');
            $settings=getSettings(EMAIL_SETTING_FILE);
            $settings['smtp_host']        = $host;
            $settings['smtp_user']        = $user;
            $settings['smtp_pass']        = $pwd;
            $settings['smtp_port']        = $port;
            $settings['from_email']       = $from_email;
            $settings['from_user'] =        $from_user;
            $settings['mailpath']         = $mailpath;
            setSettings($settings, EMAIL_SETTING_FILE);
        }
        $data['obj']=getSettings(EMAIL_SETTING_FILE);
        $this->template->write_view('content', 'backends/settings/email', $data);
        $this->template->render();
    }

    public function reset_mail_settings()
    {
        resetEmail();
        redirect('admin/settings/mail');
    }

    public function push()
    {
        if (isset($_POST['app_id'])) {
            $app_id=$this->input->post('app_id');
            $rest_key=$this->input->post('rest_key');

            $settings=getSettings(PUSH_SETTING_FILE);
            $settings['app_id']        = $app_id;
            $settings['rest_key']        = $rest_key;
            setSettings($settings, PUSH_SETTING_FILE);
        }
        $data['obj']=getSettings(PUSH_SETTING_FILE);
        $this->template->write_view('content', 'backends/settings/push', $data);
        $this->template->render();
    }

    public function reset_push()
    {
        resetPush();
        redirect('admin/settings/push');
    }
    public function opening_hours(){

        $data['record'] = $this->get("opening_hours", array(),"","row");
        $this->template->write_view('content', 'backends/settings/opening_hours' , $data);
        $this->template->render();
    }
    public function add(){
        if($this->input->post()){
            if(empty($this->input->post("emergency_closed"))){
                $data['emergency_closed'] = 'no';

            }else{
                $data['emergency_closed'] = 'yes';

            }
            if(empty($this->input->post("ring_status"))){
                $data['ring_status'] = 'no';

            }else{
                $data['ring_status'] = 'yes';

            }
            if(empty($this->input->post('m_closed'))){
                $data['m_start_time'] = $this->input->post('m_start_time');
                $data['m_end_time'] = $this->input->post('m_end_time');
                $data['m_closed'] = 'no';
            }else{
                $data['m_closed'] = 'yes';
            }

            if(empty($this->input->post('tu_closed'))){
                $data['tu_start_time'] = $this->input->post('tu_start_time');
                $data['tu_end_time'] = $this->input->post('tu_end_time');
                $data['tu_closed'] = 'no';
            }else{
                $data['tu_closed'] = 'yes';
            }

            if(empty($this->input->post('w_closed'))){
                $data['w_start_time'] = $this->input->post('w_start_time');
                $data['w_end_time'] = $this->input->post('w_end_time');
                $data['w_closed'] = 'no';
            }else{
                $data['w_closed'] = 'yes';
            }

            if(empty($this->input->post('th_closed'))){
                $data['th_start_time'] = $this->input->post('th_start_time');
                $data['th_end_time'] = $this->input->post('th_end_time');
                $data['th_closed'] = 'no';
            }else{
                $data['th_closed'] = 'yes';
            }

            if(empty($this->input->post('f_closed'))){
                $data['f_start_time'] = $this->input->post('f_start_time');
                $data['f_end_time'] = $this->input->post('f_end_time');
                $data['f_closed'] = 'no';
            }else{
                $data['f_closed'] = 'yes';
            }

            if(empty($this->input->post('sa_closed'))){
                $data['sa_start_time'] = $this->input->post('sa_start_time');
                $data['sa_end_time'] = $this->input->post('sa_end_time');
                $data['sa_closed'] = 'no';
            }else{
                $data['sa_closed'] = 'yes';
            }

            if(empty($this->input->post('su_closed'))){
                $data['su_start_time'] = $this->input->post('su_start_time');
                $data['su_end_time'] = $this->input->post('su_end_time');
                $data['su_closed'] = 'no';
            }else{
                $data['su_closed'] = 'yes';
            }

            $data_record = $this->get("opening_hours",array(),"","row");
            if(empty($data_record)){
                $is_updated = $this->log("opening_hours",$data);
            }else{
                $is_updated = $this->update("opening_hours",array("id" => 1) ,$data);
            }
            if($is_updated){
                $data['record'] = $this->get("opening_hours",array(),"","row");
                $this->template->write_view('content', 'backends/settings/opening_hours',$data);
                $this->template->render();
            }

            
        }
    }

    public function log($tbl , $data){

        $this->db->insert($tbl , $data);
        return $this->db->insert_id();
    }

    public function update($tbl , $whr , $data){

        $this->db->where($whr);
        $this->db->update($tbl , $data);
        return TRUE;
    }
    public function get($tbl , $whr = array() , $slct = '*' , $return_type = 'array'){

        $this->db->select($slct);
        if(!empty($whr)){
            $this->db->where($whr);
        }
        $query = $this->db->get($tbl);
        if($query->num_rows() > 0){
            if($return_type == 'array'){
                return $query->result_array();
            }else{
                return $query->row_array();
            }
        }else{
            return FALSE;
        }
    }
}
