<?php
require APPPATH.'/libraries/REST_Controller.php';
if (isset($_SERVER['HTTP_ORIGIN'])) {
    // Decide if the origin in $_SERVER['HTTP_ORIGIN'] is one
    // you want to allow, and if so:
	header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
	header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}

// Access-Control headers are received during OPTIONS requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

	if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        // may also be using PUT, PATCH, HEAD etc
		header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         

	if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
		header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

	exit(0);
}
class settings_api extends REST_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('users_model');
	}

	function settings_get() 
	{ 
		$this->load->helper('settings');
		$data=getSettings(GENERAL_SETTING_FILE);
		$this->response($data);
	} 
	function today_availability_get(){
		$isClosed = FALSE;
		date_default_timezone_set('Asia/Jerusalem');
		$today = date('D');
		$time = date('H:i');
		$data = $this->users_model->get_new("opening_hours",array(),"","row");
		if($data['emergency_closed'] == 'yes'){
			$isClosed = TRUE;
		}else{
			if($today == 'Mon'){
				if($data['m_closed'] == 'yes'){
					$isClosed = TRUE;
				}else{
					if($time >= $data['m_start_time'] && $time <= $data['m_end_time']){
						$isClosed = FALSE;
					}else{
						$isClosed = TRUE;
					}
				}
			}
			elseif ($today == 'Tue') {
				if($data['tu_closed'] == 'yes'){
					$isClosed = TRUE;
				}else{
					if($time >= $data['tu_start_time'] && $time <= $data['tu_end_time']){
						$isClosed = FALSE;
					}else{
						$isClosed = TRUE;
					}
				}
			}
			elseif ($today == 'Wed') {
				if($data['w_closed'] == 'yes'){
					$isClosed = TRUE;
				}else{
					if($time >= $data['w_start_time'] && $time <= $data['w_end_time']){
						$isClosed = FALSE;
					}else{
						$isClosed = TRUE;
					}
				}
			}
			elseif ($today == 'Thu') {
				if($data['th_closed'] == 'yes'){
					$isClosed = TRUE;
				}else{
					if($time >= $data['th_start_time'] && $time <= $data['th_end_time']){
						$isClosed = FALSE;
					}else{
						$isClosed = TRUE;
					}
				}
			}
			elseif ($today == 'Fri') {
				if($data['f_closed'] == 'yes'){
					$isClosed = TRUE;
				}else{
					if($time >= $data['f_start_time'] && $time <= $data['f_end_time']){
						$isClosed = FALSE;
					}else{
						$isClosed = TRUE;
					}
				}
			}
			elseif ($today == 'Sat') {
				if($data['sa_closed'] == 'yes'){
					$isClosed = TRUE;
				}else{
					if($time >= $data['sa_start_time'] && $time <= $data['sa_end_time']){
						$isClosed = FALSE;
					}else{
						$isClosed = TRUE;
					}
				}
			}
			else{
				if($data['su_closed'] == 'yes'){
					$isClosed = TRUE;
				}else{
					if($time >= $data['su_start_time'] && $time <= $data['su_end_time']){
						$isClosed = FALSE;
					}else{
						$isClosed = TRUE;
					}
				}
			}
		}
		if($isClosed){
			$res = array(
                "type" => TRUE,
                "msg" => "Restaurant is closed.",
            );
		}else{
			$res = array(
                "type" => FALSE,
                "msg" => "Restaurant is open.",
            );
		}

	$this->response($res);
}
public function test_get(){
	echo date('Y-m-d H:i:s');
	die;
}

}
?>