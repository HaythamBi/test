<?php 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
class Home extends MY_Controller{
   	function __construct()
	{
		parent::__construct();
		$this->load->helper('settings_helper');
	}

function test(){
	$CI =& get_instance();
	$CI->load->helper('settings');
	$configs = getSettings(EMAIL_SETTING_FILE);

	$subject = 'test';
	$body ='setup lai cms cac thu, test lai het';
		
	//if send by smtp
	$configs['smtp_debug']=3;
	//$configs['smtp_crypto'] = 'ssl'; 
	//$configs['debug_output']= 'error_log';  
	var_dump($configs);
	
	$CI->load->library('email',$configs);

	$CI->email->initialize($configs);
	$result = $CI->email
	->from($configs['from_email'],$configs['from_user'])
	// ->to('lynkleedinh@gmail.com')
	->to('srdslm8890@gmail.com')
	->subject($subject)
	->message($body)
	->send();
	// print_r($result);die();
}


	function index(){

	}

	function food(){
		$settings=getSettings(GENERAL_SETTING_FILE);
		$id=$this->input->get('id');
		$this->load->model('food_model');
		$obj=$this->food_model->get_by_id($id);
		$data['obj']=$obj[0];

		$data['settings']=$settings;
		$this->load->view('food',$data);
	}
}
?>