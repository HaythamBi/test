<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
use Kreait\Firebase\Factory;
use Kreait\Firebase\ServiceAccount;
 
class Firebase
{
     public function __construct() {
       $this->CI =& get_instance();
    }
    public function init(){

        $factory = (new Factory)->withServiceAccount($_SERVER['DOCUMENT_ROOT'].'/cms/application/config/tortia-37136-firebase-adminsdk-l2mf8-08b5bd011a.json')->withDatabaseUri('https://tortia-37136.firebaseio.com');
        return $factory->createDatabase();
    }
}