<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<title>Restaurant CMS</title>
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url().'statics/bootstrap/css/bootstrap.min.css'?>" />
<!-- <link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url().'statics/bootstrap/css/bootstrap-responsive.min.css'?>"/> -->

<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url().'statics/admin-lte/css/AdminLTE.min.css'?>"/>
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url().'statics/admin-lte/css/skins/_all-skins.css'?>"/>

<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url().'statics/font-awesome/css/font-awesome.min.css'?>"/>

<script type="text/javascript" src="<?php echo base_url().'statics/js/jquery.min.js'?>"></script>
<script type="text/javascript" src="<?php echo base_url().'statics/bootstrap/js/bootstrap.min.js'?>"></script>

<script type="text/javascript" src="<?php echo base_url().'statics/admin-lte/js/adminlte.min.js'?>"></script>
<script type="text/javascript" src="<?php echo base_url().'statics/admin-lte/js/demo.js'?>"></script>

<script type="text/javascript" src="<?php echo base_url().'statics/js/jquery_validation/jquery.validate.min.js'?>"></script>
<script type="text/javascript" src="<?php echo base_url().'statics/js/jquery_validation/additional-methods.min.js'?>"></script>

<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url().'statics/css/index.css'?>"/>
<?php
$query = $this->db->get('opening_hours');
$data = $query->row_array();
?>
<div>
    <input type="hidden" name="ring_status" id="ring_status" value="<?= !empty($data)?$data['ring_status']:'' ?>">
    <audio id="myAudio">
        <source src="http://customer1.eastus.cloudapp.azure.com/cms/alarm.mp3" type="audio/mpeg">
        </audio>
    </div>

    <div id="alarm_modal" class="modal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header bg-primary">
                    <h3 class="modal-title">New Order</h3>
                </div>
                <div class="modal-body">
                    <p class="text-primary text-center">Someone placed an order.</p>
                </div>
                <div class="modal-footer" style="text-align: center;">
                    <button type="button" class="btn btn-primary" style="padding-left: 50px; padding-right: 50px;" id="ok_order">Ok</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://www.gstatic.com/firebasejs/8.8.0/firebase-app.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.8.0/firebase-database.js"></script>

    <script type="text/javascript">
        const firebaseConfig = {
            apiKey: "AIzaSyB5dY7HqMHqWWOddbrSemiNcmE7ybrrFOI",
            authDomain: "tortia-37136.firebaseapp.com",
            databaseURL: "https://tortia-37136.firebaseio.com",
            projectId: "tortia-37136",
            storageBucket: "tortia-37136.appspot.com",
            messagingSenderId: "613153207826",
            appId: "1:613153207826:web:9c1dd0294418a478aa8acb",
            measurementId: "G-W1LZZM91E2"
        };

    // Initialize Firebase
    const app = firebase.initializeApp(firebaseConfig);

    var i = 0;
    var starCountRef = firebase.database().ref('order_received');
    starCountRef.on('value', (snapshot) => {
        const data = snapshot.val();
        console.log(data);
        var ring_status = document.getElementById("ring_status").value;
        if(i == 1 && ring_status == 'yes'){
            $('#myAudio')[0].play();
            $('#myAudio').attr('loop' , '');
        }
        $('#alarm_modal').modal('show');
        i = 1;
    });
</script>
<script type="text/javascript">
    $(document).on('click' , '#ok_order' , function(event) {
        $('#ok_order').attr("disabled", "disabled");
        $('#myAudio').removeAttr('loop');
        $('alarm_modal').modal('hide');
        window.location = '<?= base_url() ?>' + 'admin/orders';       
        // location.reload();
        // var formData = new FormData($('#driver_form')[0]);

    });
</script>